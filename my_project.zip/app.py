from flask import Flask, render_template, request, redirect, url_for, send_file
import mysql.connector
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import io
import datetime

app = Flask(__name__)

# ---------- MySQL Connection ----------
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="pass@123",  # put your MySQL root password
    database="bus_booking"
)
cursor = db.cursor(dictionary=True)

# ---------- Routes ----------
@app.route('/')
def index():
    cursor.execute("SELECT * FROM buses")
    buses = cursor.fetchall()
    return render_template('index.html', buses=buses)

@app.route('/book/<int:bus_id>', methods=['GET', 'POST'])
def book(bus_id):
    cursor.execute("SELECT * FROM buses WHERE id = %s", (bus_id,))
    bus = cursor.fetchone()

    if request.method == 'POST':
        name = request.form['name']
        seats = int(request.form['seats'])

        if seats <= bus["seats"]:
            new_seats = bus["seats"] - seats
            cursor.execute("UPDATE buses SET seats = %s WHERE id = %s", (new_seats, bus_id))
            cursor.execute(
                "INSERT INTO bookings (name, bus_id, seats_booked) VALUES (%s, %s, %s)",
                (name, bus_id, seats)
            )
            db.commit()

            # get the booking ID for the ticket
            cursor.execute("SELECT LAST_INSERT_ID() AS id")
            booking_id = cursor.fetchone()["id"]

            return redirect(url_for('ticket', booking_id=booking_id))
        else:
            return "❌ Not enough seats available!"
    return render_template('book.html', bus=bus)

@app.route('/ticket/<int:booking_id>')
def ticket(booking_id):
    cursor.execute("""
        SELECT b.id AS booking_id, b.name, bu.route, bu.time, b.seats_booked, b.booking_time
        FROM bookings b
        JOIN buses bu ON b.bus_id = bu.id
        WHERE b.id = %s
    """, (booking_id,))
    booking = cursor.fetchone()
    return render_template('ticket.html', booking=booking)

@app.route('/download_ticket/<int:booking_id>')
def download_ticket(booking_id):
    cursor.execute("""
        SELECT b.id AS booking_id, b.name, bu.route, bu.time, b.seats_booked, b.booking_time
        FROM bookings b
        JOIN buses bu ON b.bus_id = bu.id
        WHERE b.id = %s
    """, (booking_id,))
    booking = cursor.fetchone()

    buffer = io.BytesIO()
    pdf = canvas.Canvas(buffer, pagesize=letter)
    pdf.setTitle("Bus Ticket")

    # Header
    pdf.setFont("Helvetica-Bold", 20)
    pdf.drawString(200, 750, "🚌 Bus Ticket")

    pdf.setFont("Helvetica", 12)
    pdf.drawString(50, 710, f"Ticket ID: {booking['booking_id']}")
    pdf.drawString(50, 690, f"Passenger Name: {booking['name']}")
    pdf.drawString(50, 670, f"Route: {booking['route']}")
    pdf.drawString(50, 650, f"Bus Time: {booking['time']}")
    pdf.drawString(50, 630, f"Seats Booked: {booking['seats_booked']}")
    pdf.drawString(50, 610, f"Booking Date/Time: {booking['booking_time']}")
    pdf.drawString(50, 590, f"Issued On: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    pdf.line(50, 580, 550, 580)
    pdf.drawString(50, 550, "Thank you for booking with BusGo! Have a safe journey 🚌")

    pdf.save()
    buffer.seek(0)
    return send_file(buffer, as_attachment=True, download_name=f"ticket_{booking_id}.pdf", mimetype='application/pdf')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)

